<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>my first website after COVID-19</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <!-- Lista e fruta perimeve -->
        <div class="col-xs-12 col-md-6">
          <ol>
            <li>1 kg kumblla</li>
            <li>1 shalqin</li>
            <li>5 banane "Bana King"</li>
          </ol>
        </div>
        <!-- Lista e gjerave per tualet -->
        <div class="col-xs-12 col-md-6">
          <ul>
            <li>Leter higjenike</li>
            <li>3 Sapuna</li>
            <li>Ilac robash</li>
            <li class="trt">Lenor</li>
          </ul>
        </div>
      </div><!-- End row -->
      <p class="tekstiKuq meTeMedha">Some content</p>
      <button id="testing" class="btn btn-success">Me kliko</button>
    </div><!-- End container -->
  </body>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script>
    $('#testing').click( function() {
      alert("Button is clicked");
    });
  </script>
</html>
