$(document).ready(function(){
beforeLoading();
afterLoading();
ngjyrosTekstin();
animateDivs();
moveRectangleLeft();
moveRectangleRight();
removeFromView();
}) ;

function beforeLoading(){
  $("#fshehTekst").click(function(){
    $(".someText").hide();
  })
}

function afterLoading(){
  $("#shfaqTekst").click(function(){
    $(".someText").show();
  })
}

function ngjyrosTekstin() {
  $(".someText").dblclick(function(){
    $(this).css("color","red");
  })
}

function animateDivs(){
  $("#elementiLevizes").click(function(){
      $("#fadeShpejte").fadeIn().removeClass("hidden");
      $("#fadeMesatar").fadeIn("slow").removeClass("hidden");
      $("#fadeNgadale").fadeIn(3000).removeClass("hidden");
  });
}

//levizja e katrorit
function moveRectangleLeft(){
  $("#moveRectangle").click(function(){
    $(".retangle").animate({left:'250px'});
  });
}

function moveRectangleRight(){
  $("#moveRectangleRight").click(function(){
    $(".retangle").animate({left:'-100px'});
  });
}

function removeFromView(){
  $("#removeRetangle").click(function(){
    $(".retangle").animate({height:'toggle'});
  });
}

function validateForm(){
 $("#first_form").submit(function(e){
   e.preventDefault();
   var first_name = $("#first_name").val();
   var last_name = $("#last_name").val();
   var email = $("#email").val();
   var pass = $("#password").val();

   $(".error").remove();

   if(first_name.length < 1){
     $('#first_name').after('<span class="error">This field is required</span>');
   }
   if(last_name.length < 1){
     $('#last_name').after('<span class="error">This field is required</span>');
   }
   if(email.length < 1){
     $('#email').after('<span class="error">This field is required</span>');
   }else{
			var regEx = /^[A-Z0-9][a-z0-9._%+-]{0,63}@(?:[A-Za-z0-9]{1,63}\.){1,125}[A-Za-z]{2,63}$/;
			var validEmail = regex.test(email);
			if(!validEmail){
				$('#email').after('<span class="error">Enter a valid email!</span>');
			}
		}
   if(pass.length < 8){
     $('#password').after('<span class="error">Password must be at least 8 characters!</span>');
   }
 });

}
