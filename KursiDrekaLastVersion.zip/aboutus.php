<?php include "header.php" ;?>
   <div class="container">
     <div class="row">
       <button onclick="emerFunksioni()">Shfaq Hello</button>
       <p id="pershendetje"></p>
       <!-- <button onclick="tabelat()">Array shfaq</button> -->
        <button id="fshehTekst">Fsheh</button>
        <button id="shfaqTekst">Shfaq</button>
        <p id="afishimTabele"></p>
        <div class="someText">
          Lorem Ipsum is simply dummy text of the printing and typesetting industry.
          Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
          It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
          It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
        </div>
        <br>
        <button id="elementiLevizes" class="btn btn-default">Fillo animimim</button>
        <div id="fadeShpejte" class="redBox hidden">Fast Fade</div>
        <div id="fadeMesatar" class="pinkBox hidden">Medium Fade</div>
        <div id="fadeNgadale" class="blueBox hidden">Slow Fade</div>
     </div>
   </div>
   <section id="animatedSide">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-6 col-md-4">
            <button id="moveRectangle">Leviz Katror</button>
            <button id="moveRectangleRight">Kthe Katror</button>
            <button id="removeRetangle">Fshih</button>
          </div>
          <div class="col-xs-12 col-6 col-md-8">
            <div class="retangle"></div>
          </div>
        </div>
      </div>
   </section>

<?php include "footer.php";?>
