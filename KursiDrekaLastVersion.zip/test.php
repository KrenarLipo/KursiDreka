<?php

echo "Hello World";

 ?>
