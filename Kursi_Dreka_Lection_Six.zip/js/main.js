
    var test = "Jeni duke studiuar javascript";
    var extension = "Shtese Stingesh";

    var problem_result = "Rezultati";

    var a = 3;
    var b = 4;

     //test, extension etj etj
    //Concatenation
    console.log(test +' '+extension+' kot');
    console.log(a+''+b);
    console.log(problem_result+': '+(a+b));

function showData() {
   document.getElementById('mesazhi').innerHTML = Date();
}

function ngjyrosTekstin(){
    document.getElementById('ngjyrosjeBlu').style.color = "#00f";
}

function showPershendetja() {
  var persh;
  var time = new Date().getHours();
  console.log(time);
   time = 2;
  if(time<10 && time>5){
    persh = "Miremengjes";
  }else if(time<20 && time>10){
    persh = "Pershendetje";
  }else {
    persh = "Mbaroi 24";
  }

  document.getElementById("mesazhiPershendetje").innerHTML = persh;
}

function ditaJaves(){
  var dita;

  switch (new Date().getDay()){
    case 0:
      dita = "Sunday";
      break;
    case 1:
      dita = "Monday";
      break;
    case 2:
      dita = "Tuesday";
      break;
  }
  document.getElementById("ditaJaves").innerHTML = "Sot eshte" + dita;
}
//------------- 0 ---- 1 --------- 2 --- 3 ---------- 4
var makinat = ["BMW","MERCEDEZ","FORD","FIAT","RANGE ROVER"];
var text = "";
var i;

for(i=0; i<makinat.length; i++){
  if( makinat[i] = "BMW"){
    text = makinat[i] + "<br>";
  }else{
    text = "Nuk kemi BMW";
  }
}

document.getElementById("listimMakinash").innerHTML = text;

/* ===== Shfaqja me objekt ==== */
var txt = "";
var person = {
  fname:"Florie",
  lname: "Islamaj",
  age: 25
};

var x;

for (x in person){
  txt += person[x] + " ";
}

document.getElementById("listimPersonash").innerHTML = txt;

/* ===== Cikli while ===== */
var numrat = "";
var i = 1;
do {
  numrat += "<br>Numri eshte " + i ;
  i++;
}
while(i<=10);

document.getElementById("mesazhiWhile").innerHTML = numrat;
