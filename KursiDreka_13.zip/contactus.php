<?php include "header.php" ;?>
<div class="container-fluid">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
      <li data-target="#carousel-example-generic" data-slide-to="1"></li>
      <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="item active">
        <img class="d-block w-100" src="img/slideOne.jpg" alt="First Slide">
      </div>
      <div class="item">
        <img class="d-block w-100" src="img/slideTwo.jpg" alt="Second Slide">
      </div>
      <div class="item">
        <img class="d-block w-100" src="img/slideThree.jpg" alt="Third Slide">
      </div>
      <!-- Shigjetat ndryshuese -->
  		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
  					<i class="fas fa-arrow-left"></i>
  		</a>
  		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
  			<i class="fas fa-arrow-right"></i>
  		</a>
    </div><!-- End carousel inner -->
  </div><!-- End carousel -->
</div><!-- End container fluid -->

<div class="container">
  <div class="row">
  				<div class="col-md-8">
  					<h4>Left Side</h4>
  					<form id="first_form" method="post" action="">
  						<div>
  							<label for="first_name">First Name</label>
  							<input type="text" id="first_name" name="first_name" required>
  						</div>
  						<div>
  							<label for="last_name">Last Name</label>
  							<input type="text" id="last_name" name="last_name" required>
  						</div>
  						<div>
  							<label for="email">Email</label>
  							<input type="email" id="email" name="email" required>
  						</div>
  						<div>
  							<label for="password">Password</label>
  							<input type="password" id="password" name="password" required>
  						</div>
  						<div>
  							<input type="submit" value="Submit">
  						</div>
  					</form>
  				</div>
  				<div class="col-md-4">
  					<h4>Right Side</h4>
  						<?php
  						  //function emerFunksioni(){
  							  //return "something";
  						  //}
  		          //echo "<br>".emerFunksioni();
  	            ?>
  				</div>
  			</div>
</div>
<?php include "footer.php";?>
