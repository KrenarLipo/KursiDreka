<?php include "header.php" ; ?>

<div class="container">

<?php 

$tess = "Kursi Dreka";
$kursi = "PER PHP!";
$viti = 2020;

function shfaqVitin($var){
    return $var;
}

echo "<div class='row'>";

echo "<h2>Hello World ".$tess." ".$kursi." ".$viti."</h2>";

$tess = 1;

$tess = $tess + 2;

echo "<br>".$tess."<br>";

echo "Numri ".shfaqVitin(45);

echo "</div>";

?>

</div>

<?php include "footer.php"; ?>
