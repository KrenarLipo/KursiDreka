<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <met description="Website makinash">

    <title>my first website after COVID-19</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">

  </head>

  <body>
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#">My website</a>
        </div>
        <ul class="nav navbar-nav">
          <li class="active"><a href="#">Home</a></li>
          <li><a href="#">Page two</a></li>
          <li><a href="#">Page three</a></li>
        </ul>
      </div>
    </nav>
    <div class="container">
      <div class="row">
        <!-- Lista e fruta perimeve -->
        <div class="col-xs-12 col-md-6">
          <ol>
            <li>1 kg kumblla</li>
            <li>1 shalqin</li>
            <li>5 banane "Bana King"</li>
          </ol>
        </div>
        <!-- Lista e gjerave per tualet -->
        <div class="col-xs-12 col-md-6">
          <ul class="listaTualet">
            <li>Leter higjenike</li>
            <li>3 Sapuna</li>
            <li>Ilac robash</li>
            <li class="trt">Lenor</li>
          </ul>
        </div>
      </div><!-- End row -->

      <div class="row">
        <div class="col-12 col-sm-6 col-md-6">
          <!-- butonat e vjeter -->
          <p id="ngjyrosjeBlu" class="tekstiKuq meTeMedha">Some content</p>
          <button id="testing" class="btn btn-success" onclick="showData()">Shfaq Daten edhe oren</button>
          <p id="mesazhi"></p>
          <p id="mesazhiWhile"></p>
          <!-- Butoni per ngjyrosje -->
          <button id="btnNgjyros" onclick="ngjyrosTekstin()">Ngjyros</button>
        </div>
        <div class="col-12 col-sm-6 col-md-6">
          <!-- butonat e rinj -->
          <button id="pershendetja" class="btn btn-success" onclick="showPershendetja()">Shfaq Pershendetjen</button>
          <p id="mesazhiPershendetje"></p>
          <button class="btn btn-info" onclick="ditaJaves()">Shfaq Diten</button>
          <p id="ditaJaves"></p>
          <p id="listimMakinash"></p>
          <p id="listimPersonash"></p>
          <p id="celesatTabela"></p>
          <p id="mapping"></p>
          <p id="filtering"></p>
          <p id="rrenja"></p>
        </div>
      </div>
     <!-- Ushtrimi numer nje
     Te krijohet nje button qe affishon
     shumezimin e numrit 5 me numrin 6
     ne nje sektor ne faqe, gjate klikimit,
     ku merr edhe ngjyren e verdhe -->

     <!-- Ushtrimi numer dy
     Ne nje tabele me produkte farmacie,
     te bridhet tabela derisa te gjej
     dizifenktantin e duarve dhe te afishohet vendodhja e dizifektantin ne tabele
     tek nje paragraf htmlje
      -->
    </div><!-- End container -->
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-md-6">
          <button class="btn btn-success" onclick="getColoredElement()">Shfaq rezultatin</button>
          <button class="btn btn-alert" onclick = "getOnlyDizifenktant()">Shfaq</button>
          <button class="btn btn-info" onclick="mbushTabelFrutash()">Mbush Tabel</button>
        </div>
        <div class="col-xs-12 col-md-6">
          <p id="totali30" class="tekstiProdhim"></p>
          <p id="vendiTabela"></p>
          <button class="btn btn-default" onclick="bashkimDietik()">Shfaq dieten</button>
        </div>
      </div>
    </div>

  </body>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <noscript>
    Sorry, you need to activate Javascript!
  </noscript>
</html>
