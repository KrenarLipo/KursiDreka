<?php

include "header.php" ;

$query = "SELECT * FROM cars";
$result = $connection->query($query)->fetchAll();

?>
<div class="container">
    <div class="row">
        <h1 align="center">Makinat tona</h1>
        <div class="table-responsive">
            <div align="left">
                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#insertCar">
                Shto Makinat
                </button>
                <div class="modal fade" id="insertCar" tabindex="-1" role="dialog" aria-labelledby="insertCarLabel">
                <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-labelledby="insertCarLabel">
                    <span aria-hidden="true">&times;</span>
                    <h4 class="modal-title" id="insertCarLabel">Shto Makina</h4>
                  </button>
                </div>
                <div class="modal-body">
                    <form id="form_one" method="post" action="">
                    <label>Mark</label>
                    <input id="marka" name="marka" type="text" class="form-control" required>
                    <label>Price</label>
                    <input id="cmimi" name="cmimi" type="number" class="form-control" required>
                    <label>Production Year</label>
                    <input id="viti" name="viti" type="date" class="form-control" required>
                   
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="car_id" id="car_id" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Hiq</button>
                    <input type="submit" name="form_one_button" id="form_one_button" value="Shto Makine" class="btn btn-success">
                </form>
                </div>
            </div><!-- End align left div -->
            </div>
             
            </div>
        </div>
        <table id="car_data" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="20%">Marka e makinës</th>
                        <th width="20%">Çmimi i makinës</th>
                        <th width="20%">Vit i prodhimit</th>
                        <th width="10%">Kodi</th>
                        <th width="30%">Veprime</th>
                    </tr>
                </thead>
            </table>
    </div> <!-- End row -->
</div> <!-- End container -->

<?php
echo"<pre>";
print_r($result);
echo"</pre>";

include "footer.php" ;

?>