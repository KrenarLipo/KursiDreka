<?php
//footer here
 ?>
</body>
<!-- <script src="js/jquery.min.js"></script> -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- <script src="js/main.js"></script> -->
<script src="js/workingWithJQuery.js"></script>
<script>
$('.carousel').carousel({
 interval: 2000
})
</script>

<noscript>
  Sorry, you need to activate Javascript!
</noscript>
</html>
