<?php

include "header.php" ; 
//-------0ra-min--sec-muaj-dita-viti
$d=mktime(17, 11, 30, 10, 16, 2020);
$created_at = date("Y-m-d h:i:sa", $d);

   $stmt = $connection->prepare("
    INSERT INTO cars (mark, price, production_year, created_at)
    VALUES (:mark, :price, :production_year, :created_at)   
    ");
    $result = $stmt->execute(
        array (
            ':mark'=>$_POST['mark'],
            ':price'=>$_POST['price'],
            ':production_year'=>$_POST['production_year'],
            ':created_at' => $created_at
        )
    );
    if(!empty($result)){?>
    <script>
        document.getElementById("successmsg").innerHTML = "Makina u shtua me sukses";
    </script>
<?php } include "footer.php" ; ?>   