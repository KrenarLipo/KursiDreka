<!DOCTYPE html>
<head>
<title>First website after COVID-19</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="wrapper">
  <p class="ngjyreKuqe germeMadhe">This is a paragraph.</p>
</div>
</body>
</html>
