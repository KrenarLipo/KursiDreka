<?php
//footer here
 ?>
</body>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="js/workingWithJQuery.js"></script>
<noscript>
  Sorry, you need to activate Javascript!
</noscript>
</html>
