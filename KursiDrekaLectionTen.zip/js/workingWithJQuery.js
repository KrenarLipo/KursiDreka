$(document).ready(function(){
beforeLoading();
afterLoading();
ngjyrosTekstin();
}) ;

function beforeLoading(){
  $("#fshehTekst").click(function(){
    $(".someText").hide();
  })
}

function afterLoading(){
  $("#shfaqTekst").click(function(){
    $(".someText").show();
  })
}

function ngjyrosTekstin() {
  $(".someText").dblclick(function(){
    $(this).css("color","red");
  })
}
