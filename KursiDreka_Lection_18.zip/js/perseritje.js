function emerFunksioni() {
  var numberOne = 6;
  var numberTwo = 4;
  if(numberOne = 3){
    document.getElementById("pershendetje").innerHTML = "Numer tek";
  }
  if(numberOne = 6){
    document.getElementById("pershendetje").innerHTML = "Numer cift";
  }
}

function tabelat(){
                // 0   --------  1 ------------ 2
  var arr_one = ["element nje", "element 2", "element 3"];
  document.getElementById("afishimTabele").innerHTML = arr_one[1];
  for(var i=0; i<arr_one.length; i++){
    console.log(arr_one[i]);
  }
}
