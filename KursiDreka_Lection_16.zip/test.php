<?php include "header.php" ; 
    
 echo "<div class='container'>";   
$tess = "Kursi Dreka";
$kursi = "PER PHP!";
$viti = 2020;

function shfaqVitin($var){
    return $var;
}

echo "<div class='row'>";

echo "<h2>Hello World ".$tess." ".$kursi." ".$viti."</h2>";

$tess = 1;

$tess = $tess + 2;

echo "<br>".$tess."<br>";

echo "Numri ".shfaqVitin(45);
echo "</div>";
?>

<div class="container">

<?php 
/* ===== Arrays in PHP ===== */
$cars = array("Volvo","BMW","Toyota", 5);
echo "<div class='col-25'>";
echo "<ul class='withoutPoints'>";
foreach($cars as $key=>$c){
    echo "<li>".$key." | ".$c."</li>";
}
echo "</ul>";
echo "</div><div class='col-25'>";
           // $key => $value
$age = array("Peter"=>"35", "Ben"=>"26", "Denis"=>"23");
echo "<ol>";
foreach($age as $key=>$value) {
    echo "<li>".$key." is ".$value." years old </li>";
}
echo "</ol></div>";

echo "<div class='col-25'>";

/* ===== Classic for ===== */
for($x=10; $x <= 100; $x+=10){
    echo "Numri eshte ".$x."<br>";
}
echo"</div><div class='col-25'>";

/* ===== While cicle ===== */
$y = 1;

while($y<=10){
    echo "Numri eshte: $y <br>";
    $y++;
}
echo "</div>";

//echo "<br>";
//echo"<pre>";
//print_r($cars);
//echo"</pre>";
//var_dump($cars);


echo "</div>";

?>

</div>

<div class="container">
    <div class="row">
        <h2>Te dhenat e marra nga databaza</h2>
        <?php
           $stmt = $connection->query("SELECT * FROM users")->fetchAll();
            foreach($stmt as $row){
                echo $row['name'].' '.$row['surname']."<br>\n";
            }

           //print_r($stmt);
           $ids = 2;
           $onlyOne = $connection->query("SELECT * FROM users WHERE id=$ids")->fetch();
           //print_r($onlyOne);
           echo $onlyOne['name'].' '.$onlyOne['surname'].' ka ditelindjen ne daten: <b>'.$onlyOne['birthdate'].'</b>';
        ?>
    </div>
</div>

<?php include "footer.php"; ?>
