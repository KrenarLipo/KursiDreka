<?php

$servername = "localhost";
$username = "root";
$password = "";

try {
    $connection = new PDO("mysql:host=$servername;dbname=phpproject", $username, $password);
    //set the PDO connection
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected Successfully";
}catch(PDOException $e){
    echo "Connection failed: " . $e->getMessage();
}

?>