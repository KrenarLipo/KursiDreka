# Lista e giteve

florieislamaj97@gmail.com

emiljanamuharem@outlook.com

adelinasadiku32@gmail.com

tomailda19@gmail.com

ramaldopinjolli@gmail.com

denisdervishi01@gmail.com

erlindb.75@icloud.com

elvitr9@gmail.com

gegaeldi@gmail.com

adelinasadiku133@gmail.com
