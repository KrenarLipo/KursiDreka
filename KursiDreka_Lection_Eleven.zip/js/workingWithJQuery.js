$(document).ready(function(){
beforeLoading();
afterLoading();
ngjyrosTekstin();
animateDivs();
}) ;

function beforeLoading(){
  $("#fshehTekst").click(function(){
    $(".someText").hide();
  })
}

function afterLoading(){
  $("#shfaqTekst").click(function(){
    $(".someText").show();
  })
}

function ngjyrosTekstin() {
  $(".someText").dblclick(function(){
    $(this).css("color","red");
  })
}

function animateDivs(){
  $("#elementiLevizes").click(function(){
      $("#fadeShpejte").fadeIn().removeClass("hidden");
      $("#fadeMesatar").fadeIn("slow").removeClass("hidden");
      $("#fadeNgadale").fadeIn(3000).removeClass("hidden");
  });
}
