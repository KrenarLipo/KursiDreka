<!DOCTYPE html>
<html>
  <head>
    <title>my first website after COVI-19</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="wrapper">
      <p class="tekstiKuq meTeMedha">Some content</p>
      <!-- Lista e renditjes se pazareve -->
      <div class="fullContent">
        <!-- Lista e fruta perimeve -->
        <div class="leftSide">
          <ol>
            <li>1 kg kumblla</li>
            <li>1 shalqin</li>
            <li>5 banane "Bana King"</li>
          </ol>
        </div>

        <!-- Lista e gjerave per tualet -->
        <div class="rightSide">
          <ul>
            <li>Leter higjenike</li>
            <li>3 Sapuna</li>
            <li>Ilac robash</li>
            <li class="trt">Lenor</li>
          </ul>
        </div>
      </div>
    </div>
  </body>
</html>
