<?php

include "header.php" ; 

 $markaMakines = $_POST['marka'];
 $cmimiaMakines = $_POST['cmimi'];
 $vitProdhimi = $_POST['viti'];

echo json_encode(array("statusCode"=>200));


include "footer.php" ; 


?>